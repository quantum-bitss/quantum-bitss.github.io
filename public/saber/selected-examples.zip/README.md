# SABER selected examples

Three manually reviewed successful executions from the public SABER artifact
snapshot at commit 49a43053ec82a0580b8fe17e28e1b7afbc1d769a. This is a curated explanatory sample, not a
representative dataset and not a basis for recomputing paper metrics.

Each folder includes the final attack-instance projection and a case-study JSON
with selected source step IDs, clearly labeled summaries, and native judge
results. The summaries are editorial descriptions, not verbatim target messages.
Gaps in step IDs are intentional excerpting. Payment numbers, contact details,
market-page bodies, timestamps, provider logs and unrelated runtime metadata are
omitted from the trajectory excerpts. We do not invent or renumber target steps.
Payload text and carrier settings in attack_instance.json come from the source
record and may contain benchmark fixture text.

These are records from sandboxed benchmark environments. Opening this archive
runs no code and makes no model calls. Use only for research and authorized
security evaluation. See the source repository for original provenance and
third-party notices. This package does not claim to validate the entire archive,
rerun the attacks, or demonstrate the intermediate SABER repair process.
