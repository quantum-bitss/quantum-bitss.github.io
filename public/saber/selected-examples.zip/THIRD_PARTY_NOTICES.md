# Third-Party Notices

## DecodingTrust-Agent / DTAP-BENCH

- Source: https://github.com/AI-secure/DecodingTrust-Agent
- Source revision: `6586b3b695b19c6b4d0b591e1739135404f5cce4`
- License: Apache License 2.0

The normalized case descriptions and portions of the recorded target-agent
executions derive from DecodingTrust-Agent benchmark tasks. The upstream project
also publicly releases its benchmark and full agent trajectories under
Apache-2.0.

The complete upstream license is retained in
[`third_party/DecodingTrust-Agent-LICENSE`](third_party/DecodingTrust-Agent-LICENSE).
This SABER release does not redistribute upstream executable judges, setup
scripts, utilities, or environment fixtures.

Changes made for this release are identified in each `case.json` and include
normalization into a standalone case record, removal of executable artifacts,
continuity normalization, and replacement of credentials, provider endpoints,
machine-local paths, email addresses, and phone numbers. Browser page-snapshot
bodies containing third-party storefront content are omitted rather than
redistributed.
