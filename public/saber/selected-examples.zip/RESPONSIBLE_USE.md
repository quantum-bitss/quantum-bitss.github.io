# Responsible Use

This archive is research data from simulated agent environments. It contains
prompt-injection payloads and examples of unsafe target-agent behavior in areas
including credential handling, data access, financial actions, code execution,
and CBRN-related requests.

Use the data for authorized safety evaluation, analysis, and defensive research.
Do not execute the attack instances against real services, accounts, people, or
infrastructure. The repository intentionally excludes runnable environments,
setup scripts, credentials, and provider endpoints.

Email addresses and phone numbers are release-specific pseudonyms. They must not
be interpreted as real identities or contact details.
